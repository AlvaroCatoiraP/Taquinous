﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taquin.Gui
{
    internal class RoolsLabel : Label
    {
        private string rools;
        private Label roolsLabel;

        public RoolsLabel()
        {

            Text = "" +
                "Règles du Jeu\r\n\r\n    " +
                "Objectif : Alignez les symboles sur une ligne ou une colonne à partir de plusieurs grilles consécutives.\r\n\r\n    " +
                "Début du Jeu :\r\n\r\n        Le joueur commence avec un score de 0 et trois vies.\r\n\r\n        " +
                "Un compte à rebours indique le temps restant pour chaque tour.\r\n\r\n    " +
                "Déplacement :\r\n\r\n        " +
                "Le joueur clique sur un carreau pour tenter de déplacer un carreau adjacent vers un emplacement vide.\r\n\r\n        " +
                "Si le déplacement est valide, le carreau se déplace et un nouvel emplacement vide est créé.\r\n\r\n    " +
                "Scoring :\r\n\r\n        " +
                "Le joueur marque des points pour chaque tour réussi avant la fin du compte à rebours.\r\n\r\n        " +
                "Perte d'une vie si le compte à rebours atteint zéro sans succès.\r\n\r\n    " +
                "Niveaux de difficulté :\r\n\r\n        " +
                "Trois niveaux de difficulté avec des grilles de tailles variées.\r\n\r\n        " +
                "Le joueur doit réussir plusieurs tours pour passer au niveau suivant.\r\n\r\n    " +
                "Top 10 :\r\n\r\n        " +
                "Les scores sont sauvegardés dans un Top 10 visible, incluant la date, le pseudo et le score.\r\n\r\n    " +
                "Fin de Partie :\r\n\r\n       " +
                "Après chaque partie, le joueur reçoit un retour sur ses résultats et peut revenir au menu principal.\r\n\r\n    " +
                "Fin du Jeu :\r\n\r\n        " +
                "Le jeu se termine lorsque le joueur perd toutes ses vies.";

            ForeColor = Color.Black;
            AutoSize = true;
            Location = new Point(100, 100);
            Font = new Font("Arial", 10, FontStyle.Bold);
            TextAlign = ContentAlignment.MiddleCenter;
            Padding = new Padding(30);
           
        }

    }
}
