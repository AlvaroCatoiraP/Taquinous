﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Taquin.Metier
{
    /// <summary>
    /// Représente le plateau du jeu Taquin.
    /// </summary>
    internal class Board
    {
        private List<Tile> tiles;
        private List<List<Cell>> grid;
        private int size;

        private int target;
        private int direction_Target; // 1 pour vertical, 2 pour horizontal
        private int position_target;
        private Random random;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Board"/>.
        /// </summary>
        /// <param name="size">Taille du plateau.</param>
        public Board(int size)
        {
            this.size = size;
            tiles = new List<Tile>();
            grid = new List<List<Cell>>();
            this.random = new Random();
            this.target = random.Next(1, size + 2);

            Init_Tiles();
            this.tiles = tiles.OrderBy(t => random.Next()).ToList();
            PlaceTiles();

            this.direction_Target = random.Next(1, 3);
            this.position_target = random.Next(0, size);
        }

        /// <summary>
        /// Initialise les tuiles du plateau.
        /// </summary>
        public void Init_Tiles()
        {
            int tiles_size = (size * size) - size - 1;

            for (int i = 0; i < size; i++)
            {
                tiles.Add(new Tile(target));
            }
            for (int i = 0; i < tiles_size; i++)
            {
                tiles.Add(new Tile(random.Next(target + 1, 25)));
            }
        }

        /// <summary>
        /// Place les tuiles sur le plateau de jeu.
        /// </summary>
        public void PlaceTiles()
        {
            int indexTile = 0;
            for (int row = 0; row < size; row++)
            {
                grid.Add(new List<Cell>());

                for (int col = 0; col < size; col++)
                {
                    grid[row].Add(new Cell());
                    if (indexTile < tiles.Count)
                    {
                        grid[row][col].Set_Tile(tiles[indexTile]);
                    }
                    indexTile++;
                }
            }
        }

        /// <summary>
        /// Déplace une tuile adjacente si possible.
        /// </summary>
        /// <param name="row_Current_Tile">Ligne de la tuile actuelle.</param>
        /// <param name="col_Current_Tile">Colonne de la tuile actuelle.</param>
        /// <returns>Vrai si un déplacement a été effectué, sinon faux.</returns>
        public bool MoveAdjacentTile(int row_Current_Tile, int col_Current_Tile)
        {
            if (row_Current_Tile >= 0 && row_Current_Tile < size - 1)
                if (move_tile(row_Current_Tile + 1, col_Current_Tile, 1))
                    return true;
            if (row_Current_Tile > 1 && row_Current_Tile < size)
                if (move_tile(row_Current_Tile - 1, col_Current_Tile, 1))
                    return true;
            if (col_Current_Tile >= 0 && col_Current_Tile < size - 1)
                if (move_tile(row_Current_Tile, col_Current_Tile + 1, 2))
                    return true;
            if (col_Current_Tile > 1 && col_Current_Tile < size)
                if (move_tile(row_Current_Tile, col_Current_Tile - 1, 2))
                    return true;

            return false;
        }

        /// <summary>
        /// Déplace une tuile dans une direction spécifiée.
        /// </summary>
        /// <param name="row">Ligne de la tuile.</param>
        /// <param name="col">Colonne de la tuile.</param>
        /// <param name="direction">Direction du déplacement (1 pour vertical, 2 pour horizontal).</param>
        /// <returns>Vrai si un déplacement a été effectué, sinon faux.</returns>
        public bool move_tile(int row, int col, int direction = 0)
        {
            bool isMoved = false;
            if (col >= 0 && direction != 1)
            {
                if (col < size - 1 && !grid[row][col + 1].IsOccupied())
                {
                    grid[row][col + 1].Set_Tile(grid[row][col].Get_tile());
                    grid[row][col].Free_Cell();
                    isMoved = true;
                }
                if (col > 0 && col < size && !grid[row][col - 1].IsOccupied())
                {
                    grid[row][col - 1].Set_Tile(grid[row][col].Get_tile());
                    grid[row][col].Free_Cell();
                    isMoved = true;
                }
            }
            if (row >= 0 && direction != 2)
            {
                if (row < size - 1 && !grid[row + 1][col].IsOccupied())
                {
                    grid[row + 1][col].Set_Tile(grid[row][col].Get_tile());
                    grid[row][col].Free_Cell();
                    isMoved = true;
                }
                if (row > 0 && row < size && !grid[row - 1][col].IsOccupied())
                {
                    grid[row - 1][col].Set_Tile(grid[row][col].Get_tile());
                    grid[row][col].Free_Cell();
                    isMoved = true;
                }
            }
            return isMoved;
        }

        /// <summary>
        /// Obtient la grille du plateau.
        /// </summary>
        public List<List<Cell>> Get_Board_Grid() => grid;

        /// <summary>
        /// Obtient la valeur cible.
        /// </summary>
        public int Get_Target() => target;

        /// <summary>
        /// Obtient la taille de la grille.
        /// </summary>
        public int Get_GridSize() => grid.Count;

        /// <summary>
        /// Obtient la direction cible.
        /// </summary>
        public int Get_Target_direction() => direction_Target;

        /// <summary>
        /// Obtient la position cible.
        /// </summary>
        public int Get_Target_position() => position_target;
    }
}
