﻿

using System;
using System.Collections.Generic;
using Taquin.Metier;


namespace Taquin
{
    /// <summary>
    /// Représente une partie du jeu Taquin.
    /// </summary>
    internal class Game
    {
        private Level current_Level;
        private Player player;
        private Round current_round;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Game"/>.
        /// </summary>
        /// <param name="login">Le nom du joueur.</param>
        public Game(string login)
        {
            this.player = new Player(login);
            current_Level = new Level(3);
            current_round = current_Level.Get_current_round();
        }

        /// <summary>
        /// Vérifie si l'objectif du niveau est correctement atteint.
        /// </summary>
        /// <returns>Vrai si l'objectif est atteint, sinon faux.</returns>
        public bool IsCorrect_Target()
        {
            bool isCorrect_Target = true;
            this.current_round = this.current_Level.Get_current_round();
            Board current_board = current_round.Get_Board();
            int current_Target = current_board.Get_Target();
            List<List<Cell>> current_Grid = current_round.Get_Board().Get_Board_Grid();
            int current_Size = current_round.Get_Board().Get_GridSize();
            int current_position = current_round.Get_Board().Get_Target_position();

            if (current_board.Get_Target_direction() == 1)
            {
                for (int i = 0; i < current_Size && isCorrect_Target; i++)
                {
                    if (current_Grid[i][current_position].IsOccupied())
                    {
                        if (current_Grid[i][current_position].Get_tile().Get_Symbol() != current_Target)
                        {
                            isCorrect_Target = false;
                        }
                    }
                    else
                    {
                        isCorrect_Target = false;
                    }
                }
            }
            else if (current_board.Get_Target_direction() == 2)
            {
                for (int i = 0; i < current_Size; i++)
                {
                    if (current_Grid[current_position][i].IsOccupied())
                    {
                        if (current_Grid[current_position][i].Get_tile().Get_Symbol() != current_Target)
                        {
                            isCorrect_Target = false;
                        }
                    }
                    else
                    {
                        isCorrect_Target = false;
                    }
                }
            }
            return isCorrect_Target;
        }

        /// <summary>
        /// Obtient le tour actuel de la partie.
        /// </summary>
        /// <returns>Le tour actuel.</returns>
        public Round Get_current_round()
        {
            return current_Level.Get_current_round();
        }

        /// <summary>
        /// Obtient le joueur actuel de la partie.
        /// </summary>
        /// <returns>Le joueur actuel.</returns>
        public Player Get_Player()
        {
            return player;
        }

        /// <summary>
        /// Obtient le niveau actuel de la partie.
        /// </summary>
        /// <returns>Le niveau actuel.</returns>
        public Level Get_current_level()
        {
            return this.current_Level;
        }

        /// <summary>
        /// Réinitialise la partie en recommençant depuis le premier niveau.
        /// </summary>
        internal void reset()
        {
            player.reset();
            current_Level = new Level(3);
            current_round = current_Level.Get_current_round();
        }
    }
}

