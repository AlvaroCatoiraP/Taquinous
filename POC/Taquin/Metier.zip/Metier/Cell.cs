﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taquin.Metier
{
    /// <summary>
    /// Représente une cellule du plateau de jeu Taquin.
    /// </summary>
    internal class Cell
    {
        private Tile tile;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Cell"/>.
        /// </summary>
        public Cell()
        {
        }

        /// <summary>
        /// Vérifie si la cellule est occupée par une tuile.
        /// </summary>
        /// <returns>Vrai si la cellule contient une tuile, sinon faux.</returns>
        public bool IsOccupied()
        {
            return tile != null;
        }

        /// <summary>
        /// Obtient la tuile contenue dans la cellule.
        /// </summary>
        /// <returns>La tuile présente dans la cellule.</returns>
        public Tile Get_tile()
        {
            return tile;
        }

        /// <summary>
        /// Définit une tuile dans la cellule.
        /// </summary>
        /// <param name="tile">La tuile à placer dans la cellule.</param>
        public void Set_Tile(Tile tile)
        {
            this.tile = tile;
        }

        /// <summary>
        /// Libère la cellule en supprimant la tuile qu'elle contient.
        /// </summary>
        public void Free_Cell()
        {
            this.tile = null;
        }

        /// <summary>
        /// Retourne une représentation sous forme de chaîne de la cellule.
        /// </summary>
        /// <returns>Une chaîne représentant la cellule.</returns>
        public override string ToString()
        {
            return tile.ToString();
        }
    }
}
