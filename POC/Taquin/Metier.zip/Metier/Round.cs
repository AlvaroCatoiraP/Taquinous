﻿using Taquin.Metier;


namespace Taquin
{

    /// <summary>
    /// Représente un tour de jeu dans le jeu Taquin.
    /// </summary>
    internal class Round
    {
        private int board_Size;
        private Board board;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Round"/>.
        /// </summary>
        /// <param name="board_Size">Taille du plateau de jeu.</param>
        public Round(int board_Size)
        {
            this.board_Size = board_Size;
            if (board_Size >= 3)
            {
                this.board = new Board(this.board_Size);
            }
        }

        /// <summary>
        /// Obtient le plateau de jeu associé au tour.
        /// </summary>
        /// <returns>Le plateau de jeu du tour.</returns>
        public Board Get_Board()
        {
            return this.board;
        }
    }
}
