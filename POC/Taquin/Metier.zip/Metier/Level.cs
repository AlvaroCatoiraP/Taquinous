﻿using System;
using System.Collections.Generic;
using System.Linq;
using Taquin.Metier;


namespace Taquin
{

    /// <summary>
    /// Représente un niveau dans le jeu Taquin.
    /// </summary>
    internal class Level
    {
        private List<Round> rounds;
        private int dificulty;
        private int secs;
        private int targetScore;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Level"/>.
        /// </summary>
        /// <param name="dificulty">Le niveau de difficulté du jeu.</param>
        public Level(int dificulty)
        {
            this.targetScore = 20;
            rounds = new List<Round>();
            this.dificulty = dificulty;
            Round firs_round = new Round(dificulty);
            rounds.Add(firs_round);
            this.secs = 10;
        }

        /// <summary>
        /// Ajoute un nouveau tour au niveau.
        /// </summary>
        /// <param name="round">Le tour à ajouter.</param>
        public void Add_new_round(Round round)
        {
            rounds.Add(round);
        }

        /// <summary>
        /// Obtient le tour actuel du niveau.
        /// </summary>
        /// <returns>Le tour actuel.</returns>
        public Round Get_current_round()
        {
            return rounds.Last();
        }

        /// <summary>
        /// Obtient le nombre de secondes allouées pour ce niveau.
        /// </summary>
        /// <returns>Le nombre de secondes.</returns>
        public int Get_Secs()
        {
            return secs;
        }

        internal bool ConfirmScoreSuccess(int current_score)
        {
            return current_score == targetScore;
        }

        internal int GetTargetScore()
        {
            return targetScore;
        }

    }
}
