﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taquin
{
    /// <summary>
    /// Représente une tuile dans le jeu Taquin.
    /// </summary>
    internal class Tile
    {
        private int index_Symbol;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Tile"/>.
        /// </summary>
        /// <param name="index_Symbol">Le symbole associé à la tuile.</param>
        public Tile(int index_Symbol)
        {
            this.index_Symbol = index_Symbol;
        }

        /// <summary>
        /// Obtient le symbole de la tuile.
        /// </summary>
        /// <returns>Le symbole sous forme d'entier.</returns>
        public int Get_Symbol()
        {
            return index_Symbol;
        }

        /// <summary>
        /// Retourne une représentation sous forme de chaîne de la tuile.
        /// </summary>
        /// <returns>Une chaîne représentant le symbole de la tuile.</returns>
        public override string ToString()
        {
            return index_Symbol.ToString();
        }
    }
}