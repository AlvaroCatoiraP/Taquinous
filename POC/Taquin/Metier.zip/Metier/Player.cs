﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taquin
{

    /// <summary>
    /// Représente un joueur dans le jeu Taquin.
    /// </summary>
    internal class Player
    {
        private string name;
        private int score;
        private int lifes;
        private int initLifes;

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Player"/>.
        /// </summary>
        /// <param name="name">Le nom du joueur.</param>
        public Player(string name)
        {
            this.name = name;
            this.score = 0;
            this.lifes = 3;
            this.initLifes = lifes;
        }

        /// <summary>
        /// Diminue le nombre de vies du joueur.
        /// </summary>
        public void Decrement_lifes() { if (lifes > 0) lifes--; }

        /// <summary>
        /// Obtient le score actuel du joueur.
        /// </summary>
        public int GetScore() { return score; }

        /// <summary>
        /// Obtient le nombre de vies restantes du joueur.
        /// </summary>
        public int Get_Lifes() { return lifes; }

        /// <summary>
        /// Diminue le score du joueur.
        /// </summary>
        public void Decrement_Score() { if (score > 0) score--; }

        /// <summary>
        /// Augmente le score du joueur.
        /// </summary>
        public void Increment_Score() { score += 5; }

        /// <summary>
        /// Réinitialise les vies du joueur.
        /// </summary>
        public void reset_lifes() { lifes = initLifes; }

        /// <summary>
        /// Obtient le nombre initial de vies du joueur.
        /// </summary>
        public int GetInitLifes() { return initLifes; }

        /// <summary>
        /// Réinitialise le score et les vies du joueur.
        /// </summary>
        internal void reset()
        {
            this.score = 0;
            this.reset_lifes();
        }
    }
}